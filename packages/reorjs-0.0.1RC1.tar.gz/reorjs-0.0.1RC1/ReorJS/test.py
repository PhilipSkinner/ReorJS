import remote.rredis

r = remote.rredis.RedisRemote(name='redis', hostname='localhost', table='application')

print r.fetch_data(rows=2)
print r.fetch_data(rows=2)

r.resetCursor()

print r.fetch_data(rows=5)
