Secure Distributed Messaging
============================

This is an example of secure distributed messaging.

There is some work to be done setting up this example.

You will need two instances of ReorJS running, each working with a separate API database.

You will need several compute nodes, some configured to connect to each of the ReorJS instances.

